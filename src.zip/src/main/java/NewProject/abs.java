package NewProject;

public class abs {
}
